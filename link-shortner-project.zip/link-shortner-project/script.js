//longURL to shortURL converter

let button =document.getElementById("shorten")

button.addEventListener('click',short)

 async function short(){
 let longLink=document.getElementById("longLink").value
 let shortLink=document.getElementById("shortLink")

 const result=await fetch(`https://api.shrtco.de/v2/shorten?url=${longLink}`)
 const data=await result.json()

 shortLink.value=data.result.short_link
 console.log(shortLink.value)

}

//copy button

let copyBtn=document.getElementById("copy")

copyBtn.onclick=()=>{
    shortLink.select()

    window.navigator.clipboard.writeText(shortLink.value)
}

